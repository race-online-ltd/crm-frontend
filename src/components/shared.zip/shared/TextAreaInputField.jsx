
import TextField from '@mui/material/TextField';

export default function TextAreaInputField({
  name,
  label,
  value,
  onChange,
  onBlur,
  rows = 4, // default rows
  maxRows,
  disabled = false,
  fullWidth = true,
  error = false,
  helperText = '',
  ...rest
}) {
  return (
    <TextField
      name={name}
      label={label}
      value={value}
      onChange={onChange}
      onBlur={onBlur}
      multiline
      rows={rows}       // initial height
      maxRows={maxRows} // optional max height
      disabled={disabled}
      fullWidth={fullWidth}
      error={error}
      helperText={helperText}
      variant="outlined"
      {...rest}
    />
  );
}
