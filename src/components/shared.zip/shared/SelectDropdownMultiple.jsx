import React from 'react';
import { useField, useFormikContext } from 'formik';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';

/**
 * Reusable Multi-Select Dropdown (Formik + Yup ready)
 */
export default function SelectDropdownMultiple({
  name,
  label = 'Select Items',
  placeholder = '',
  options = [],
  limitTags = 2,
  defaultValue = [],
  disabled = false,
  searchable = true,
  fullWidth = true,
  width = 240,
  sx = {},
}) {
  const { setFieldValue } = useFormikContext();
  const [field, meta] = useField(name);

  // Map Formik value (array of ids) → full option objects
  const selectedOptions = options.filter((opt) =>
    Array.isArray(field.value) ? field.value.includes(opt.id) : false
  );

  return (
    <Autocomplete
      multiple
      limitTags={limitTags}
      options={options}
      disabled={disabled}
      readOnly={!searchable}
      value={selectedOptions.length ? selectedOptions : defaultValue}
      onChange={(_, newValues) => {
        setFieldValue(
          name,
          newValues.map((v) => v.id)
        );
      }}
      getOptionLabel={(option) => option.label || ''}
      sx={{
        width: fullWidth ? '100%' : width,
        ...sx,
      }}
      renderInput={(params) => (
        <TextField
          {...params}
          label={label}
          placeholder={placeholder}
          size="small"
          fullWidth={fullWidth}
          error={Boolean(meta.touched && meta.error)}
          helperText={meta.touched && meta.error ? meta.error : ' '}
          sx={{
            // OUTER INPUT CONTAINER
            '& .MuiOutlinedInput-root': {
              minHeight: 45,
              display: 'flex',
              alignItems: 'center',
              padding: '4px 10px !important',
            },

            // INPUT TEXT / CHIP INPUT
            '& .MuiInputBase-input': {
              fontSize: '0.8125rem',
              padding: '4px 0 !important',
            },

            // LABEL POSITIONING
            '& .MuiInputLabel-root': {
              fontSize: '0.8125rem',
              transform: 'translate(14px, 12px) scale(1)',
            },
            '& .MuiInputLabel-shrink': {
              transform: 'translate(14px, -6px) scale(0.75)',
            },
          }}
        />
      )}
    />
  );
}
