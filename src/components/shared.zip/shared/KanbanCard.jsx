// src/components/shared/KanbanCard.jsx
import React from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { 
  Box, Typography, Card, CardContent, Chip, 
  Button, ButtonGroup, Stack 
} from '@mui/material';
import {
  FilterList as FilterListIcon,
  List as ListIcon,
  ViewKanban as ViewKanbanIcon,
  PersonOutline as PersonOutlineIcon,
  Language as LanguageIcon,
  TrendingUp as TrendingUpIcon,
} from '@mui/icons-material';

export default function KanbanCard({ title = "Team Pipeline", data, setData }) {
  
  const calculateColumnTotal = (items) => {
    const total = items.reduce((acc, item) => {
      // Handles both string "৳50,000" and number 50000
      const num = typeof item.amount === 'string' 
        ? parseInt(item.amount.replace(/[^0-9]/g, ''), 10) || 0 
        : item.amount || 0;
      return acc + num;
    }, 0);
    return `৳${total.toLocaleString()}`;
  };

  const onDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination) return;
    if (source.droppableId === destination.droppableId && source.index === destination.index) return;

    const sourceCol = data[source.droppableId];
    const destCol = data[destination.droppableId];
    const sourceItems = [...sourceCol.items];
    const destItems = [...destCol.items];
    const [removed] = sourceItems.splice(source.index, 1);

    if (source.droppableId === destination.droppableId) {
      sourceItems.splice(destination.index, 0, removed);
      setData({ ...data, [source.droppableId]: { ...sourceCol, items: sourceItems } });
    } else {
      destItems.splice(destination.index, 0, removed);
      setData({
        ...data,
        [source.droppableId]: { ...sourceCol, items: sourceItems },
        [destination.droppableId]: { ...destCol, items: destItems }
      });
    }
  };

  if (!data) return null;

  return (
    <Box sx={{ p: 2, bgcolor: '#fff', borderRadius: 4, width: '100%' }}>
      {/* Header Bar */}
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 3 }}>
        <Stack direction="row" spacing={1} alignItems="center">
          <TrendingUpIcon sx={{ fontSize: 24, color: '#1976d2' }} />
          <Typography variant="h5" sx={{ fontWeight: 700, color: '#1a202c' }}>{title}</Typography>
        </Stack>
        <Stack direction="row" spacing={1}>
          <ButtonGroup size="small" variant="outlined" sx={{ bgcolor: '#f7f9fc' }}>
            {/* <Button startIcon={<ListIcon />} sx={{ color: '#718096', borderColor: '#e2e8f0', textTransform: 'none' }}>List</Button> */}
            <Button startIcon={<ViewKanbanIcon />} variant="contained" sx={{ textTransform: 'none', bgcolor: '#fff', color: '#1a202c', border: '1px solid #e2e8f0', boxShadow: 'none', '&:hover': { bgcolor: '#f7f9fc' } }}>Kanban</Button>
          </ButtonGroup>
          <Button variant="outlined" startIcon={<FilterListIcon />} size="small" sx={{ textTransform: 'none', color: '#1a202c', borderColor: '#e2e8f0', bgcolor: '#f7f9fc' }}>
            Filters
          </Button>
        </Stack>
      </Stack>

      {/* Kanban Board Container */}
      <DragDropContext onDragEnd={onDragEnd}>
        <Box sx={{ 
          display: 'flex', 
          gap: 2, 
          overflowX: 'auto', 
          pb: 2,
          alignItems: 'stretch', // KEY: Makes all columns the same height
          minHeight: '70vh' 
        }}>
          {Object.values(data).map((col) => (
            <Box 
              key={col.id} 
              sx={{ 
                minWidth: 300, 
                width: 300,
                display: 'flex', 
                flexDirection: 'column', // KEY: Allows internal components to stretch
                border: '1.5px solid #e2e8f0', 
                borderRadius: '12px', 
                overflow: 'hidden',
                bgcolor: '#f8fafc' 
              }}
            >
              {/* Image-Style Column Header */}
              <Box sx={{ bgcolor: col.color || '#1976d2', p: 1.5, color: 'white' }}>
                <Stack direction="row" justifyContent="space-between" alignItems="center">
                  <Stack direction="row" spacing={1} alignItems="center">
                    <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{col.title}</Typography>
                    <Chip 
                      label={col.items.length} 
                      size="small" 
                      sx={{ bgcolor: 'rgba(255,255,255,0.3)', color: 'white', fontWeight: 700, height: 20 }} 
                    />
                  </Stack>
                  <Box sx={{ bgcolor: 'white', px: 1, py: 0.2, borderRadius: 10 }}>
                    <Typography sx={{ color: '#1a202c', fontSize: '0.75rem', fontWeight: 800 }}>
                      {calculateColumnTotal(col.items)}
                    </Typography>
                  </Box>
                </Stack>
              </Box>

              <Droppable droppableId={col.id}>
                {(provided, snapshot) => (
                  <Box
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                    sx={{
                      p: 1.5,
                      bgcolor: snapshot.isDraggingOver ? '#edf2f7' : 'transparent',
                      flexGrow: 1, // KEY: Forces the droppable area to fill the column height
                      minHeight: '200px', // Ensures you can drop into empty columns
                      transition: 'background-color 0.2s ease'
                    }}
                  >
                    {col.items.map((item, index) => (
                      <Draggable key={item.id} draggableId={item.id} index={index}>
                        {(provided, snapshot) => (
                          <Card
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            variant="outlined"
                            sx={{
                              mb: 2,
                              borderRadius: '10px',
                              boxShadow: snapshot.isDragging ? '0 10px 20px rgba(0,0,0,0.1)' : '0 2px 4px rgba(0,0,0,0.02)',
                              borderColor: '#e2e8f0',
                              bgcolor: 'white'
                            }}
                          >
                            <CardContent sx={{ p: '16px !important' }}>
                              <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 0.5, color: '#1e293b' }}>
                                {item.name}
                              </Typography>
                              
                              <Stack spacing={1}>
                                <Stack direction="row" spacing={1} alignItems="center">
                                  <PersonOutlineIcon sx={{ fontSize: 16, color: '#94a3b8' }} />
                                  <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 500 }}>{item.user}</Typography>
                                </Stack>
                                <Stack direction="row" spacing={1} alignItems="center">
                                  <LanguageIcon sx={{ fontSize: 16, color: '#94a3b8' }} />
                                  <Chip 
                                    label={item.source} 
                                    size="small" 
                                    variant="outlined" 
                                    sx={{ height: 18, fontSize: '0.65rem', borderColor: '#e2e8f0', bgcolor: '#f8fafc', fontWeight: 600 }} 
                                  />
                                </Stack>
                              </Stack>

                              <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mt: 2, pt: 1.5, borderTop: '1px dashed #e2e8f0' }}>
                                <Typography sx={{ fontSize: '0.85rem', fontWeight: 800, color: '#0f172a' }}>
                                  {typeof item.amount === 'number' ? `৳${item.amount.toLocaleString()}` : item.amount}
                                </Typography>
                                <Chip 
                                  label={item.status} 
                                  size="small" 
                                  sx={{ bgcolor: '#eff6ff', color: '#2563eb', fontWeight: 700, fontSize: '0.6rem', height: 20, textTransform: 'uppercase' }} 
                                />
                              </Stack>
                            </CardContent>
                          </Card>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </Box>
                )}
              </Droppable>
            </Box>
          ))}
        </Box>
      </DragDropContext>
    </Box>
  );
}