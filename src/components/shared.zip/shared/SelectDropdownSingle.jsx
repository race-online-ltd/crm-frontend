// SelectDropdownSingle.jsx
import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import CircularProgress from '@mui/material/CircularProgress';
import { useField, useFormikContext } from 'formik';

/**
 * Reusable SelectDropdownSingle component
 * Props:
 * - name: string (Formik field name)
 * - label: string (Label for the dropdown)
 * - fetchOptions: async function that returns options [{ id, label }]
 * - disabled: boolean
 */
export function SelectDropdownSingle({ 
  name, 
  label,
  fetchOptions,
  disabled = false,
  searchable = true, 
}) {
  const { setFieldValue } = useFormikContext();
  const [field, meta] = useField(name);

  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleOpen = async () => {
    setOpen(true);
    if (options.length === 0) {
      setLoading(true);
      try {
        const data = await fetchOptions();
        setOptions(data);
      } catch (err) {
        console.error('Error fetching options:', err);
        setOptions([]);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <Autocomplete
    className='w-md'
      fullWidth
      disabled={disabled}
      readOnly={!searchable}
      open={open}
      onOpen={handleOpen}
      onClose={handleClose}
      isOptionEqualToValue={(option, value) => option.id === value?.id}
      getOptionLabel={(option) => option.label || ''}
      options={options}
      value={options.find((opt) => opt.id === field.value) || null}
      onChange={(event, newValue) => {
        setFieldValue(name, newValue ? newValue.id : '');
      }}
      loading={loading}
      renderInput={(params) => (
        <TextField
          {...params}
          label={label}
          error={Boolean(meta.touched && meta.error)}
          helperText={meta.touched && meta.error}
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <>
                {loading ? <CircularProgress color="inherit" size={20} /> : null}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
            sx={{ width: '500px' }}
        />
      )}
    />
  );
}

