// NumberInput.jsx
import TextField from '@mui/material/TextField';

export default function NumberInputField({
  name,
  label,
  value,
  onChange,
  onBlur,
  error = false,
  helperText = '',
  size = 'small',
  fullWidth = true,
  sx = {},
  ...rest
}) {
  return (
    <TextField
      name={name}
      label={label}
      value={value}
      onChange={(e) => {
        // only allow numbers
        const val = e.target.value;
        if (/^\d*$/.test(val)) onChange(e);
      }}
      onBlur={onBlur}
      error={error}
      helperText={helperText}
      variant="outlined"
      fullWidth
     size={size}
      sx={{
        width: fullWidth ? '100%' : '240px',
        '& .MuiInputBase-input': {
          fontSize: '0.8125rem',
          padding: '10px 10px',
        },
        '& .MuiInputLabel-root': {
          fontSize: '0.8125rem',
          transform: 'translate(14px, 10px) scale(1)',
        },
        '& .MuiInputLabel-shrink': {
          transform: 'translate(14px, -6px) scale(0.75)',
        },
        ...sx,
      }}
      {...rest}
    />
  );
}
