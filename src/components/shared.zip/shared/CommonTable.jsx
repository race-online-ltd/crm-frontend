import React from 'react';
import {
  Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TablePagination, Typography, Box
} from '@mui/material';
import TableChartIcon from '@mui/icons-material/TableChart';

const CommonTable = ({ 
  title, 
  columns, 
  rows, 
  dynamicDate, 
  maxHeight = 600,
  footerName = "Grand Total" 
}) => {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const handleChangePage = (event, newPage) => setPage(newPage);
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  // Helper to calculate totals for the footer
  const calculateTotal = (columnId) => {
    return rows.reduce((sum, row) => {
      const val = row[columnId];
      if (typeof val === 'string') {
        // Remove symbols like %, ৳, or commas before summing
        const numeric = parseFloat(val.replace(/[%,৳,]/g, '')) || 0;
        return sum + numeric;
      }
      return sum + (Number(val) || 0);
    }, 0);
  };

  // Define widths for the sticky columns so they align perfectly
  const stickyWidths = {
    totalInvSum: 120,
    totalTarget: 120,
    totalAch: 150,
  };

  return (
    <Paper sx={{ width: '100%', borderRadius: 2, overflow: 'hidden', border: '1px solid #e0e0e0' }}>
      <Box sx={{ p: 1.5, display: 'flex', alignItems: 'center', gap: 1, bgcolor: '#fff' }}>
        <TableChartIcon sx={{ color: '#1976d2', fontSize: 18 }} />
        <Typography variant="body1" sx={{ fontWeight: 600, color: '#1a202c' }}>
          {title}
        </Typography>
      </Box>

      <TableContainer sx={{ maxHeight }}>
        <Table 
          stickyHeader 
          size="small" 
          sx={{ borderCollapse: 'separate', borderSpacing: 0 }}
        >
          <TableHead>
            {/* ROW 1 */}
            <TableRow>
              <TableCell 
                rowSpan={2} 
                sx={{ 
                  bgcolor: '#f8fafc', fontWeight: 700, border: '1px solid #e0e0e0', minWidth: 150,
                  position: 'sticky', left: 0, zIndex: 10 
                }}
              >
                KAM Name
              </TableCell>
              <TableCell align="center" colSpan={6} sx={{ bgcolor: '#f0f7ff', fontWeight: 700, border: '1px solid #e0e0e0' }}>
                {dynamicDate}
              </TableCell>
              <TableCell 
                align="center" colSpan={3} 
                sx={{ 
                  bgcolor: '#f1f5f9', fontWeight: 700, border: '1px solid #e0e0e0',
                  position: 'sticky', right: 0, zIndex: 10 
                }}
              >
                TOTAL
              </TableCell>
            </TableRow>

            {/* ROW 2 */}
            <TableRow>
              {columns.map((col, index) => {
                // Determine sticky right position
                let rightPos = 'auto';
                if (col.id === 'totalAch') rightPos = 0;
                if (col.id === 'totalTarget') rightPos = stickyWidths.totalAch;
                if (col.id === 'totalInvSum') rightPos = stickyWidths.totalAch + stickyWidths.totalTarget;

                const isStickyRight = rightPos !== 'auto';

                return (
                  <TableCell 
                    key={col.id} align="center" 
                    sx={{ 
                      bgcolor: isStickyRight ? '#f1f5f9' : '#f8fafc', 
                      fontWeight: 700, fontSize: '0.65rem', border: '1px solid #e0e0e0',
                      position: isStickyRight ? 'sticky' : 'static',
                      right: rightPos,
                      zIndex: isStickyRight ? 11 : 1,
                      minWidth: stickyWidths[col.id] || 100
                    }}
                  >
                    {col.label}
                  </TableCell>
                );
              })}
            </TableRow>
          </TableHead>

          <TableBody>
            {rows
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row, index) => (
                <TableRow key={index} hover>
                  <TableCell sx={{ 
                    border: '1px solid #e0e0e0', bgcolor: '#fff', fontWeight: 500,
                    position: 'sticky', left: 0, zIndex: 2 
                  }}>
                    {row.kamName}
                  </TableCell>
                  {columns.map((col) => {
                    let rightPos = 'auto';
                    if (col.id === 'totalAch') rightPos = 0;
                    if (col.id === 'totalTarget') rightPos = stickyWidths.totalAch;
                    if (col.id === 'totalInvSum') rightPos = stickyWidths.totalAch + stickyWidths.totalTarget;
                    
                    const isStickyRight = rightPos !== 'auto';

                    return (
                      <TableCell 
                        key={col.id} align="center" 
                        sx={{ 
                          border: '1px solid #e0e0e0', fontSize: '0.8rem',
                          bgcolor: isStickyRight ? '#f9fafb' : '#fff',
                          position: isStickyRight ? 'sticky' : 'static',
                          right: rightPos,
                          zIndex: isStickyRight ? 2 : 0
                        }}
                      >
                        {row[col.id] !== undefined ? row[col.id] : '0'}
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}

            {/* STICKY GRAND TOTAL FOOTER */}
            <TableRow sx={{ position: 'sticky', bottom: 0, zIndex: 12 }}>
              <TableCell sx={{ 
                bgcolor: '#334155', color: '#fff', fontWeight: 700, border: '1px solid #475569',
                position: 'sticky', left: 0, zIndex: 13 
              }}>
                {footerName}
              </TableCell>
              {columns.map((col) => {
                let rightPos = 'auto';
                if (col.id === 'totalAch') rightPos = 0;
                if (col.id === 'totalTarget') rightPos = stickyWidths.totalAch;
                if (col.id === 'totalInvSum') rightPos = stickyWidths.totalAch + stickyWidths.totalTarget;
                
                const isStickyRight = rightPos !== 'auto';
                const totalValue = calculateTotal(col.id);

                return (
                  <TableCell 
                    key={`total-${col.id}`} align="center" 
                    sx={{ 
                      bgcolor: isStickyRight ? '#1e293b' : '#334155', 
                      color: '#fff', fontWeight: 700, border: '1px solid #475569',
                      position: isStickyRight ? 'sticky' : 'static',
                      right: rightPos,
                      zIndex: isStickyRight ? 13 : 12
                    }}
                  >
                    {/* Formatting logic: Add % or symbols based on column type */}
                    {col.id.toLowerCase().includes('ach') ? `${totalValue.toFixed(1)}%` : totalValue.toLocaleString()}
                  </TableCell>
                );
              })}
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination
        rowsPerPageOptions={[10, 25, 50]}
        component="div"
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Paper>
  );
};

export default CommonTable;